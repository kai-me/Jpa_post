package snippet;

public class Snippet {
	const { MongoClient } = require('mongodb');
	
	const uri = 'mongodb://localhost:27017'; // URI de conexão com o MongoDB
	const dbName = 'MonitoramentoDeTrafego'; // Nome do banco de dados
	
	async function connectToMongoDB() {
	  const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
	
	  try {
	    await client.connect();
	    console.log('Conectado ao MongoDB');
	
	    return client.db(dbName);
	  } catch (err) {
	    console.error(err);
	  }
	}
	
	// Agora você pode usar a função connectToMongoDB() para obter uma instância do banco de dados.
	
}

